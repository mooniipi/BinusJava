package main;

import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	Vector<String> orderIDList = new Vector();
	Vector<String> customerList = new Vector();
	Vector<String> franchiseList = new Vector();
	Vector<String> foodList = new Vector();
	Vector<Integer> quantityList = new Vector();
	Vector<String> orderNoteList = new Vector();
	Vector<Double> totalPriceList = new Vector();

public Main() {
		
		int input;
		do {
		System.out.println("goFoT");
		System.out.println("==========");
		System.out.println("1. Order goFoT");
		System.out.println("2. View All Order History");
		System.out.println("3. Exit");
		System.out.print(">>");
		input = scan.nextInt();
		scan.nextLine();
		
		
			switch (input) {
			case 1:
				customers();
				break;
				
			case 2 :
				
				customerReg(); 
				
				break;
				
			case 3 :
				System.out.println("Good Luck Have Fun :)");
				break;

			default:
				break;
			}
		}while(input != 3);
		
		
		
		}
	
	void customers() {
	String customerName = "" , franchise = "" , food = "" , orderNote = "";
	int quantity;
	int foodPrice;
	do{
		System.out.println("Input Customer Name [ Must be between 7 - 15 characters and Starts with Mr. or Mrs. ] : ");
		customerName = scan.nextLine();
	}while(!(customerName.length() >= 15 && customerName.length() <= 7 || customerName.startsWith("Mr.") || customerName.startsWith("Mrs. ")));
		
	do {
		System.out.println("Input Franchise Name [ Fkc | Cmd] (Case Insesitive): ");
		franchise = scan.nextLine();
	}while(!(franchise.equalsIgnoreCase("Fkc") || franchise.equalsIgnoreCase("Cmd")));
	
	do {
		System.out.println("Input Food Name [ Burger | Fried Chicken | French Fries ] (Case Sensitive) : ");
		food = scan.nextLine();
		if(food.equals("Burger")) {
			foodPrice = 17000;
		}else if(food.equals("Fried Chicken")) {
			foodPrice = 22000;
		}else {
			foodPrice = 12000;
		}
	}while(!(food.equals("Burger") || food.equals("Fried Chicken") || food.equals("French Fries")));
	
	do {
		System.out.println("Input Order Note [ Must contain atleast 2 words and contain Thank You ] : ");
		orderNote = scan.nextLine();
	}while(!(orderNote.contains("Thank You")));
	
	do {
		System.out.println("Input Quantity [ Must be more than 0 ] : ");
		quantity = scan.nextInt();
		scan.nextLine();
	}while(quantity < 0);
	
	String alp = "FKCMD";
	int idx;
	StringBuilder sb = new StringBuilder();
	
	int length = 2;
	
	for(int i = 0; i < length; i++) {
		idx = rand.nextInt(alp.length());
		char Char = alp.charAt(idx);
		sb.append(Char);
		
	}
	String customerID = sb.toString();
	String x1 = "RI" + customerID + rand.nextInt(1000);
	
	String confirm = "";
	double tax;
	double totalPrice;
	tax = (foodPrice * quantity)*0.1;
	totalPrice = (foodPrice * quantity)*tax;
	do {
	System.out.println("Order Information");
	System.out.println("=====================");
	System.out.println("Order ID = " + x1);
	System.out.println("Customer Name = " +customerName);
	System.out.println("Food Name = " +food);
	System.out.println("Food Price = " +foodPrice);
	System.out.println("Quantity = " +quantity);
	System.out.println("Order Note = " +orderNote);
	System.out.println("Franchise Name = " +franchise);
	System.out.println("Tax = " +tax);
	System.out.println("Total Price = " +totalPrice);
	System.out.println("Confirm Order [ y | n ] (Case Sensitive) : ");
	confirm = scan.nextLine();
	if(confirm.equals("y")) {
		System.out.println("Sccuess Order!");
	}
	orderIDList.add(x1);
	customerList.add(customerName);
	franchiseList.add(franchise);
	foodList.add(food);
	quantityList.add(quantity);
	orderNoteList.add(orderNote);
	totalPriceList.add(totalPrice);	
	}while(!(confirm.equals("y") || confirm.equals("n")));
			
	}
	void customerReg() {
	for(int i = 0 ; i < orderIDList.size() ; i++) {
	System.out.println("Order ID : " + orderIDList);
	System.out.println("Customer Name : " + customerList);	
	System.out.println("Franchise Name : " + franchiseList);	
	System.out.println("Food Name : " + foodList);	
	System.out.println("Quantity : " + quantityList);	
	System.out.println("Order Note : " + orderNoteList);
	System.out.println("Total Price : " + totalPriceList);	
	}

	}

	public static void main(String[] args) {
		new Main();
	}
}

