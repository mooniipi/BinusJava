/**
 * 
 */
/**
 * 
 */
module goFoT {
}