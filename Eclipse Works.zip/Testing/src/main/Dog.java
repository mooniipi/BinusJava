package main;

public class Dog {
String breed;
int umur;
public Dog(String breed, int umur) {
	super();
	this.breed = breed;
	this.umur = umur;
}


}
