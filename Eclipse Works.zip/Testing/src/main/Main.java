package main;

import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	Vector<String> fokemonIDList = new Vector();
	Vector<String> fokemonNameList = new Vector();
	Vector<String> fokemonTypeList = new Vector();
	Vector<Integer> fokemonHpList = new Vector();
	Vector<Integer> fokemonATKList = new Vector();
	Vector<String> fokemonAbilitiesList = new Vector();
	
	public Main() {
		int input;
	do {
		
		System.out.println("FokemonT");
		System.out.println("==============");
		System.out.println("1. Insert a FokemonT");
		System.out.println("2. View Fokedex");
		System.out.println("3. Exit");
		input = scan.nextInt();
		scan.nextLine();
		
		
		switch (input) {
		case 1:
			FokemonTInput();
			break;
			
		case 2:
			FokemonDex();
			break;
		
		case 3:
			System.out.println("Thank you :)");
			break;
			
		default:
			break;
		}
		}while(input !=3);
	}
	
	
	void FokemonTInput() {
	String fokemonName;
	String fokemonType;
	String fokemonAbilities;
	int fokemonHP , fokemonAttack;
	boolean x2 = true;
	
	while (x2) {
		/*
		 * boolean charLetter = false; boolean chardigit = false; boolean charsymbol =
		 * false;
		 * 
		 * System.out.
		 * println("Insert FokemonT Name [ Must be alphabetic and Unique } : ");
		 * fokemonName = scan.next();
		 * 
		 * for(char c : fokemonName.toCharArray()) { if(Character.isLetter(c)) {
		 * charLetter = true; }else if(Character.isDigit(c)) { chardigit = true; }else {
		 * charsymbol = true; } if (charLetter = true && chardigit == false &&
		 * charsymbol == false) { x2 = false; }else { x2 = true; } }
		 */
		do {
			System.out.println("Input FokemonT Name [ Must be alphabetic and Unique ] : ");
			fokemonName = scan.nextLine();
		}while(!(fokemonName.matches("[a-zA-Z]+")));
		
		do{
		System.out.println("Insert FokemonT Type [ Fire | Grass | Water ] (Case Sensitive) : ");
		fokemonType = scan.nextLine();
		}while(!(fokemonType.equals("Fire") || fokemonType.equals("Grass") || fokemonType.equals("Water")));
	
	do {
	System.out.println("Input FokemonT Hp [ Must be between 100 - 1000 ] (Inclusive) : ");
	fokemonHP = scan.nextInt();
	scan.nextLine();
	}while(!(fokemonHP >= 100 || fokemonHP <= 1000));
	
	do {
	System.out.println("Input FokemonT Attack [ Must be between 100 - 200 ] (Exclusive) : ");
	fokemonAttack = scan.nextInt();
	scan.nextLine();
	}while(!(fokemonAttack > 100 || fokemonAttack < 200));
	
	do {
	System.out.println("Input FokemonT Abilities [ Must contain atleast 2 words ] : ");
	fokemonAbilities = scan.nextLine();
	}while(!fokemonAbilities.contains(" "));
	
	String alp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int idx;
	StringBuilder sb = new StringBuilder();
	
	int length = 2;
	
	for(int i = 0; i < length; i++) {
		idx = rand.nextInt(alp.length());
		char Char = alp.charAt(idx);
		sb.append(Char);
		
	}
	String fokemonID = sb.toString();
	String x1 = "PI" + fokemonID + rand.nextInt(1000);
	
	fokemonIDList.add(x1);
	fokemonNameList.add(fokemonName);
	fokemonTypeList.add(fokemonType);
	fokemonHpList.add(fokemonHP);
	fokemonATKList.add(fokemonAttack);
	fokemonAbilitiesList.add(fokemonAbilities);
	
	break;

	}
	}
	


	
	void FokemonDex() {
	for(int i = 0; i < fokemonIDList.size(); i++) {
		System.out.println("FokemonT ID : " +fokemonIDList);
		System.out.println("FokemonT Name : " +fokemonNameList);
		System.out.println("FokemonT Type : " +fokemonTypeList);
		System.out.println("HP : " +fokemonHpList);
		System.out.println("Attack : " +fokemonATKList);
		System.out.println("Abilities : " +fokemonAbilitiesList);
		
	}
	}

	public static void main(String[] args) {
		new Main();

	}

}
