package main;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	Vector<String> groupNameList = new Vector();
	Vector<String> idList = new Vector();
	Vector<String> ideaList = new Vector();
	Vector<String> locationList = new Vector();
	Vector<String> feedbackLinkList = new Vector();
	
	public Main() {   
	int input;
	do {	
	System.out.println("Sunib Festival");
	System.out.println("=================");
	System.out.println("1. Register for the exhibition");
	System.out.println("2. View all exhibits");
	System.out.println("3. Exit");
	System.out.print(">>>.");
	input = scan.nextInt();
	scan.nextLine();
	switch (input) {
	case 1:
		exhibitView();
		break;
		
	case 2:
		exhibitsView();
		break;
		
	case 3:
		System.out.println("See you at sunib Festival!");
		break;

	default:
		break;
		}
	}while(input !=4);
	}
	
	void exhibitView() {
	String groupName = "" , idea = "" , location = "" , feedbackLink = "";	
//	do {
//		System.out.println("Input Group Name [ Must be alphabetic and Unique ] : ");
//		groupName = scan.nextLine();
//	}while(!(groupName.matches("[a-zA-Z]+")));
	boolean x1 = true;
	while (x1) {
		boolean charLetter = false;
		boolean charDigit = false;
		boolean charSymbol = false;
		
		System.out.println("Input Group Name [ Must be alphabetic and Unique ] : ");
		groupName = scan.nextLine();
		
		for(char c : groupName.toCharArray()) {
			if (Character.isLetter(c)) {
				charLetter = true;
			}else if (Character.isDigit(c)) {
				charDigit = true;
			}else
				charSymbol = true;
		}
		
		if(charLetter == true && charDigit == false && charSymbol == false) {
			x1 = false;
		}else
			x1 = true;
	}
	
	do {
		System.out.println("Input idea [ Must be atleast contain 3 words] : ");
		idea = scan.nextLine();
	}while(idea.split(" ").length < 3);
	
	do {
		System.out.println("Input Location [ Muist be ends with 'lt.1' , 'lt.2' , or lt.3 ] : ");
		location = scan.nextLine();
	}while(!(location.endsWith("lt.1") || location.endsWith("lt.2") || location.endsWith("lt.3")));
	
	do {
		System.out.println("Input feedback link [ Must starts with 'forms.com/' : ");
		feedbackLink = scan.nextLine();
	}while(!(feedbackLink.startsWith("forms.com/")));
	
	
	String id = String.format("TB%03d", rand.nextInt(1000));
	System.out.println("Exhibition Information");
	System.out.println("=======================");
	System.out.println("Table ID : " +id);
	System.out.println("Group name : " +groupName);
	System.out.println("Idea : " +idea);
	System.out.println("Location : " +location);
	System.out.println("Feedback Link : " +feedbackLink);
	
	idList.add(id);
	groupNameList.add(groupName);
	ideaList.add(idea);
	locationList.add(location);
	feedbackLinkList.add(feedbackLink);

	}
	
	void exhibitsView() {
	System.out.println("Table ID : " +idList);
	System.out.println("Group Name : " +groupNameList);
	System.out.println("Idea : " +ideaList);
	System.out.println("Location : " +locationList);
	System.out.println("Feedback Link : " +feedbackLinkList);
	
	}
	
	

	public static void main(String[] args) {
	new Main();

	}

}
