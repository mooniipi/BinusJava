package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
	
	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> GIDList = new ArrayList();
	ArrayList<String> GNameList = new ArrayList();
	ArrayList<String> genreList = new ArrayList();
	ArrayList<Integer> priceList = new ArrayList();
	ArrayList<String> devList = new ArrayList();
	ArrayList<String> pubList = new ArrayList();
	
	boolean check (String name) {
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			if(!(Character.isAlphabetic(c))) {
				return false;
			}
		
		}
		return true;
	}
	
	void sort() {
		int a, b;
		int temp;
	
		for (int i = 0; i < priceList.size(); i++) {
		for (int j = 0; j < priceList.size()-1; j++) {
		a = priceList.get(j);
		b = priceList.get(j+1);
		
		if(a < b) {
			temp = priceList.get(j);
			priceList.set(j, priceList.get(j+1));
			priceList.set(j+1, temp);
		}
		}	
		}
	}
	
	
	public Main() {
		int input;
	do {
		System.out.println("FTeam");
		System.out.println("=========");
		System.out.println("1. Release a game");
		System.out.println("2. View All Games");
		System.out.println("3. Update Game");
		System.out.println("4. Delete Game");
		System.out.println("5. Exit");
		input = scan.nextInt();
		scan.nextLine();
		
		switch (input) {
		case 1:
			release();
			break;
			
		case 2:
			if(GIDList.isEmpty()) {
				System.out.println("No games");
			}else {
				sort();
				view();	
			}
			
			break;
			
		case 3:
			if(GIDList.isEmpty()) {
				System.out.println("No games");
			}else {
			update();
			}
			break;
			
		case 4:
			if(GIDList.isEmpty()) {
				System.out.println("No games");
			}else {
			delete();
			}
			break;

		default:
			break;
		}
	} while (input != 5);

	}
	

	
	void release() {
		String GName ="" , genre ="", devName ="", pubName="";
		int price;
		String confirmation ="";
		boolean xi = true;
		while (xi) {
			boolean hasLetter = false;
			boolean hasDigit = false;
			boolean hasSymbol = false;
			
			System.out.println("Input Game Name [ Must be alphanumberic and Unique ] : ");
			GName = scan.nextLine();
			for(char c: GName.toCharArray()) {
				if(Character.isLetter(c)) {
					hasLetter = true;
				}else if(Character.isDigit(c)) {
					hasDigit = true;
					
				}else {
					hasSymbol = true;
				}
				
				if(hasLetter == true && hasDigit == false && hasSymbol == false) {
					xi = false;
				}else
					xi = true;
			}
			
	
		}
		
		do {
			System.out.println("Input game price [ Must be more than 10000 ] : ");
			price = scan.nextInt();
			scan.nextLine();
		} while (price <= 10000);
		
		do {
			System.out.println("Input Genre [ MMORPG | RPG | FPS ] (Case Sensitive) : ");
			genre = scan.nextLine();
		} while (!(genre.equals("MMORPG") || genre.equals("RPG") || genre.equals("FPS")));
		
		do {
			System.out.println("Input Developer Name [ Must be alphabetic and more than 5 characters ] : ");
			devName = scan.nextLine();
		} while (!(check(GName) == true && GNameList.contains(GName) == false) || !(devName.length() > 5));
		
		do {
			System.out.println("Input publisher Name [ Must be more than 3 characters ] : ");
			pubName = scan.nextLine();
		} while (!(pubName.length() > 3));
		
		do {
			System.out.println("Are u sure want to buy this game [ Y | N ] (Case Sensitive) : ");
			confirmation = scan.nextLine();
			if(confirmation.equals("N")) {
				System.out.println("Back to the menu you go!");
			}else {
				break;
			}
		} while (!(confirmation.equals("Y") || confirmation.equals("N")));
		
		int money;
		int change;
		do {
			System.out.println("Input Money [ >= Game Price ] : ");
			money = scan.nextInt();
			scan.nextLine();
			if (money > price) {
				change = money-price;
				System.out.println("Change: " +change);
			}else {
				change = money-price;
				System.out.println("Change: " +change);
			}
		} while (!(money == price || money > price));
		
		String randomid ="";
		randomid = "FT" + rand.nextInt(1000);
		
		GIDList.add(randomid);
		GNameList.add(GName);
		genreList.add(genre);
		priceList.add(price);
		devList.add(devName);
		pubList.add(pubName);

	}
	

	void view() {
		for (int i = 0; i < GIDList.size(); i++) {
			System.out.println("Game ID: " +GIDList.get(i));
			System.out.println("Game name: " +GNameList.get(i));
			System.out.println("Genre: " +genreList.get(i));
			System.out.println("Price: " +priceList.get(i));
			System.out.println("Developer: " +devList.get(i));
			System.out.println("Publisher: " +pubList.get(i));
		}
	}
	
	void update() {
		sort();
		view();
		String updating;
		do {
		System.out.println("Input Game ID [e.g FT432] : ");
		updating = scan.nextLine();
		}while(!(GIDList.contains(updating)));
		
		int i = GIDList.indexOf(updating);
		
		String GName;
		boolean xi = true;
		while (xi) {
			boolean hasLetter = false;
			boolean hasDigit = false;
			boolean hasSymbol = false;
			
			System.out.println("Input Game Name [ Must be alphanumberic and Unique ] : ");
			GName = scan.nextLine();
			for(char c: GName.toCharArray()) {
				if(Character.isLetter(c)) {
					hasLetter = true;
				}else if(Character.isDigit(c)) {
					hasDigit = true;
					
				}else {
					hasSymbol = true;
				}
				
				if(hasLetter == true && hasDigit == false && hasSymbol == false) {
					xi = false;
				}else
					xi = true;
			}
			
			System.out.println("Successfully Updated game!");
			
			GNameList.set(i, GName);
		}
		
	}
	
	void delete() {
		sort();
		view();
		String deleting;
		do {
			System.out.println("Input Game ID [e.g FT432] : ");
			deleting = scan.nextLine();
		} while (!(GIDList.contains(deleting)));
		
		int i = GIDList.indexOf(deleting);
		
		GIDList.remove(i);
		GNameList.remove(i);
		genreList.remove(i);
		priceList.remove(i);
		devList.remove(i);
		pubList.remove(i);

	}
	public static void main(String[] args) {
		new Main();

	}

}
