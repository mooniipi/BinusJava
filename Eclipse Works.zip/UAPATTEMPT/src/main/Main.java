package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class Main {

	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> PIDList = new ArrayList();
	ArrayList<String> PNameList = new ArrayList();
	ArrayList<Integer> sessionList = new ArrayList();
	ArrayList<String> PTopicList = new ArrayList();
	ArrayList<String> DiffList = new ArrayList();
	ArrayList<Double> viewsList = new ArrayList();
	
	
//	private void sortingtime() {
//		
//		String nama1 , nama2 , temp;
//
//     
//        for (int i = 0; i < PIDList.size(); i++) {
//            for (int j = 0; j < PIDList.size() - 1; j++) {
//                nama1 = PIDList.get(j);
//                nama2 = PIDList.get(j + 1);
//         
//          
//                if (nama1.compareTo(nama2) > 0) {
//                    temp = PIDList.get(j);
//                    PIDList.set(j, PIDList.get(j + 1));
//                    PIDList.set(j + 1, temp);
//                
//                    Collections.swap(PIDList, j, j+1);
//                    
//                }
//    }
//       }
//	}
	
	private void sortingtype() {
		int session1, session2;
        int temp;

        for (int i = 0; i < sessionList.size(); i++) {
            for (int j = 0; j < sessionList.size() - 1; j++) {
            	session1 = sessionList.get(j);
            	session2 = sessionList.get(j + 1);

                if (session1 > session2) {
                    temp = sessionList.get(j);
                    sessionList.set(j, sessionList.get(j + 1));
                    sessionList.set(j + 1, temp);
                    
                    Collections.swap(PIDList, j, j+1);
                    Collections.swap(PNameList, j, j+1);
                    Collections.swap(PTopicList, j, j+1);
                    Collections.swap(DiffList, j, j+1);
                    Collections.swap(viewsList, j, j+1);
                    
		
                }	
            }
	}
	}
	
	public Main() {
	int input;	
		do {
			System.out.println("FiTs Practice List");
			System.out.println("============");
			System.out.println("1. Add new practice");
			System.out.println("2. View all practice");
			System.out.println("3. Update practice");
			System.out.println("4. Delete practice");
			System.out.println("5. Exit");
			input = scan.nextInt();
			scan.nextLine();
			
			switch (input) {
			case 1:
				newPractice();
				break;
				
			case 2:
				if(PIDList.isEmpty()) {
					System.out.println("There is no practice data!");
				}else {
				PView();
				}
				break;
				
			case 3:
				if(PIDList.isEmpty()) {
					System.out.println("There is no practice data!");
				}else {
					PUpdate();
				}
				break;
				
			case 4:
				if(PIDList.isEmpty()) {
					System.out.println("There is no practice data!");
				}else {
					PDelete();
				}
				break;
				
			default:
				break;
			}
			
		}while(input !=5);
		
		
		
	}
	
	private void newPractice() {
		
		String PName = "", PTopic ="", Diff ="";
		int session;
		double DiffPoints;
		double views;
		
		do {
			System.out.println("Practice Name [ Must be unique and more than 5 characters ] : ");
			PName = scan.nextLine();
		}while(PName.length() < 5);

		do {
			System.out.println("Session Number [ Must be between 1 - 12 ] (inclusive) : ");
			session = scan.nextInt();
			scan.nextLine();
		}while(session < 1 || session > 12);
		
		do {
			System.out.println("Input topic [ Must be atleast 2 words] : ");
			PTopic = scan.nextLine();
		}while(!(PTopic.contains(" ")));
		
		do {
			System.out.println("Input Difficulty Level [ Easy | Medium | Hard ] (Case Sensitive) : ");
			Diff = scan.nextLine();	
			if(Diff.equals("Easy")) {
				DiffPoints = 1000;
			}else if(Diff.equals("Medium")) {
				DiffPoints = 1500;
			}else {
				DiffPoints = 2000;
			}
		}while(!(Diff.equals("Easy")) && Diff.equals("Medium") && Diff.equals("Hard"));
		
		String randomid = "";
		randomid = rand.nextInt(1000) + "FT" + session;
		
		int randomid2;
		randomid2 = 1000 + rand.nextInt(1000);
				
		views = (PName.length() * DiffPoints) + randomid2;
		String confirmation = "";
		
		do {	
		System.out.println("Practice Information"); 	
		System.out.println("====================="); 	
		System.out.println("Practice ID: " +randomid); 	
		System.out.println("Practice Name: " +PName); 	
		System.out.println("Session: " +session); 
		System.out.println("Topic: " +PTopic);
		System.out.println("Difficulty Level: " +Diff); 	
		System.out.println("Difficulty Points: " +DiffPoints); 	
		System.out.println("Views: " +views); 	
		System.out.println("Input Confirmation [ Y | N ] : ");
		confirmation = scan.nextLine();
		if(confirmation.equals("Y")) {
			PIDList.add(randomid);
			PNameList.add(PName);
			sessionList.add(session);
			PTopicList.add(PTopic);
			DiffList.add(Diff);
			viewsList.add(views);	
		}else {
			System.out.println("Nevermind");
		}
		
		}while(!(confirmation.equals("Y") || confirmation.equals("N")));
				
	}	
	
	private void PView() {
		for(int i = 0 ; i < PIDList.size(); i++) {
		System.out.println("Practice ID: " +PIDList.get(i));
		System.out.println("Practice Name: " +PNameList.get(i));
		System.out.println("Session: " +sessionList.get(i));
		System.out.println("Topic: " +PTopicList.get(i));
		System.out.println("Difficulty Level: " +DiffList.get(i));
		System.out.println("Views: " +viewsList.get(i));
		}
	}
	
	private void PUpdate() {
		System.out.println("Input nomor: ");
		int i = scan.nextInt();
		scan.nextLine();
		
		String PName = "", PTopic ="", Diff ="";
		int session;
		double DiffPoints;
		double views;
		
		
		
		do {
			System.out.println("Practice Name [ Must be unique and more than 5 characters ] : ");
			PName = scan.nextLine();
			PNameList.set(i-1, PName);
		}while(PName.length() < 5);
		
		do {
			System.out.println("Session Number [ Must be between 1 - 12 ] (inclusive) : ");
			session = scan.nextInt();
			scan.nextLine();
			sessionList.set(i-1, session);
		}while(session < 1 || session > 12);
		
		do {
			System.out.println("Input topic [ Must be atleast 2 words] : ");
			PTopic = scan.nextLine();
			PTopicList.set(i-1, PTopic);
		}while(!(PTopic.contains(" ")));
		
		do {
			System.out.println("Input Difficulty Level [ Easy | Medium | Hard ] (Case Sensitive) : ");
			Diff = scan.nextLine();	
			if(Diff.equals("Easy")) {
				DiffPoints = 1000;
			}else if(Diff.equals("Medium")) {
				DiffPoints = 1500;
			}else {
				DiffPoints = 2000;
			}
			DiffList.set(i-1, Diff);
		}while(!(Diff.equals("Easy")) && Diff.equals("Medium") && Diff.equals("Hard"));

		String randomid = "";
		randomid = rand.nextInt(1000) + "FT" + session;
		
		int randomid2;
		randomid2 = 1000 + rand.nextInt(1000);
				
		views = (PName.length() * DiffPoints) + randomid2;
		
		PIDList.set(i-1, randomid);
		viewsList.set(i-1, views);
	}
	
	private void PDelete() {
		
		System.out.println("Input nomor: ");
		int i = scan.nextInt();
		scan.nextLine();
		
		PIDList.remove(i-1);
		PNameList.remove(i-1);	
		sessionList.remove(i-1);
		PTopicList.remove(i-1);
		DiffList.remove(i-1);
		viewsList.remove(i-1);
	}
	
	public static void main(String[] args) {
		new Main();

	}

}
