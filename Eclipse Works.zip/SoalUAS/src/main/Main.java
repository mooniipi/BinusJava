package main;

import java.util.Scanner;
import java.util.Vector;

public class Main {

	Scanner scan = new Scanner(System.in);
	
	String[] type = {" ", "Strawberry", "Coklat", "Vanilla", "Durian", "Blueberry"};
	int[] conePrice = {0, 10000, 9000, 8000, 12000, 11000};
	int[] sundaePrice = {0, 12000, 11000, 10000, 14000, 13000};
	String[] option = {" ", "Cone", "Sundae"};
	
	String[] topping = {"No Topping", "Almond", "Nut", "Oreo", "Messes"};
	int[] toppingPrice = {0, 3000, 2500, 1500, 2000};
	
//	Vector / Arraylist buat array dinamis
	Vector<Integer> noOrder = new Vector<>();
	Vector<String> iceCream = new Vector<>();
	Vector<String> coneOrSundae = new Vector<>();
	Vector<String> toppingOrder = new Vector<>();
	Vector<Integer> quantity = new Vector<>();
	Vector<Integer> priceOrder = new Vector<>();
	Vector<Integer> subTotal = new Vector<>();
	
	
	public Main() {
		// TODO Auto-generated constructor stub
		int menu = 0;
		
		do {
			System.out.println("Bee Gelato");
			System.out.println("1. Order");
			System.out.println("2. Order History");
			System.out.println("3. Exit");
			System.out.print(">>");
			try {
				menu = scan.nextInt();
				scan.nextLine();
			} catch (Exception e) {
				// TODO: handle exception
				menu = -1;
			}
			
			switch (menu) {
			case 1:
				order();
				break;
			case 2:
				orderHistory();
				break;
			case 3:
				System.out.println("Thank you");
				break;

			default:
				break;
			}
			
		} while (menu != 3);
		
		
		
		
	}

	private void orderHistory() {
		// TODO Auto-generated method stub
		System.out.println("Order History");
		System.out.println("==================================================================================");
		System.out.println("| No Order | Ice Cream Type | Topping | Cone/Sundae | Quantity | Price | subtotal|");
		System.out.println("==================================================================================");
		for (int i = 0; i < noOrder.size(); i++) {
			System.out.printf("|%9d | %-5s | %-10s | %-8s | %-8d | %-5d | %-5d |\n", noOrder.get(i), iceCream.get(i), toppingOrder.get(i), coneOrSundae.get(i), quantity.get(i), priceOrder.get(i), subTotal.get(i));
		}
		System.out.println("==================================================================================");
		
		System.out.println("Press enter to continue");
		scan.nextLine();
	}

	private void order() {
		// TODO Auto-generated method stub
		int noOrder = 0, type = 0, coneOrSundae = 0, topping = 0, quantity = 0, tempPrice = 0; 
		String iceCreamType, coneOrSundaeTemp, toppingTemp;
		
		do {
			System.out.print("Input 'No Order' [1-10000] :" );
			noOrder = scan.nextInt();
			scan.nextLine();
		} while (noOrder < 1 || noOrder > 10000);
		
		do {
			System.out.print("Type (1. Strawberry 2. Coklat 3. Vanilla 4. Durian 5. Strawberry) : ");
			type = scan.nextInt();
			scan.nextLine();
		} while (type < 1 || type > 5);
		
		do {
			System.out.println("Cone / Sundae (1. Cone 2. Sundae) : ");
			coneOrSundae = scan.nextInt();
			scan.nextLine();
		} while (coneOrSundae < 1 || coneOrSundae > 2);
		
		do {
			System.out.print("Topping (0. No Topping 1. Almond 2. Nut 3. Oreo 4. Messes) : ");
			topping = scan.nextInt();
			scan.nextLine();
		} while (topping < 0 || topping > 4);
		
		do {
			System.out.print("Quantity");
			quantity = scan.nextInt();
			scan.nextLine();
		} while (quantity < 1);
		
		if (type == 1) {
			iceCreamType = this.type[1];
			iceCream.add(iceCreamType);
		}else if (type == 2) {
			iceCreamType = this.type[2];
			iceCream.add(iceCreamType);
		}else if (type == 3) {
			iceCreamType = this.type[3];
			iceCream.add(iceCreamType);
		}else if (type == 4) {
			iceCreamType = this.type[4];
			iceCream.add(iceCreamType);
		}else if (type == 5) {
			iceCreamType = this.type[5];
			iceCream.add(iceCreamType);
		}
		
		
		if (coneOrSundae == 1) {
			coneOrSundaeTemp = "Cone";
			this.coneOrSundae.add(coneOrSundaeTemp);
		}else if (coneOrSundae == 2) {
			coneOrSundaeTemp = "Sundae";
			this.coneOrSundae.add(coneOrSundaeTemp);
		}
		
		if (topping == 0) {
			toppingTemp = this.topping[0];
			toppingOrder.add(toppingTemp);
		}else if (topping == 1) {
			toppingTemp = this.topping[1];
			toppingOrder.add(toppingTemp);
		}else if (topping == 2) {
			toppingTemp = this.topping[2];
			toppingOrder.add(toppingTemp);
		}else if (topping == 3) {
			toppingTemp = this.topping[3];
			toppingOrder.add(toppingTemp);
		}else if (topping == 4) {
			toppingTemp = this.topping[4];
			toppingOrder.add(toppingTemp);
		}
		
		this.quantity.add(quantity);
		
		
		if (type == 1 && coneOrSundae == 1) {
			tempPrice = conePrice[1];
			priceOrder.add(tempPrice);
		}else if (type == 2 && coneOrSundae == 1 ) {
			tempPrice = conePrice[2];
			priceOrder.add(tempPrice);
		}else if (type == 3 && coneOrSundae == 1 ) {
			tempPrice = conePrice[3];
			priceOrder.add(tempPrice);
		}else if (type == 4 && coneOrSundae == 1 ) {
			tempPrice = conePrice[4];
			priceOrder.add(tempPrice);
		}else if (type == 5 && coneOrSundae == 1 ) {
			tempPrice = conePrice[5];
			priceOrder.add(tempPrice);
		}else if (type == 1 && coneOrSundae == 2 ) {
			tempPrice = sundaePrice[1];
			priceOrder.add(tempPrice);
		}else if (type == 2 && coneOrSundae == 2 ) {
			tempPrice = sundaePrice[2];
			priceOrder.add(tempPrice);
		}else if (type == 3 && coneOrSundae == 2 ) {
			tempPrice = sundaePrice[3];
			priceOrder.add(tempPrice);
		}else if (type == 4 && coneOrSundae == 2 ) {
			tempPrice = sundaePrice[4];
			priceOrder.add(tempPrice);
		}else if (type == 5 && coneOrSundae == 2 ) {
			tempPrice = sundaePrice[5];
			priceOrder.add(tempPrice);
		}
		
		this.noOrder.add(noOrder);
		
		subTotal.add(tempPrice *quantity);
		
		
		System.out.println("Press enter to continue");
		scan.nextLine();
		
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
