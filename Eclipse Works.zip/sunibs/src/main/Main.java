package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<String> GNameList = new ArrayList<>();
	ArrayList<String> GIDList = new ArrayList<>();
	ArrayList<String> ideaList = new ArrayList<>();
	ArrayList<String> locationList = new ArrayList<>();
	ArrayList<String> feedbackList = new ArrayList<>();

	boolean check (String name) {
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			if (!(Character.isAlphabetic(c))) {
				return false;
			}
			
		}
		return true;
	}
	
	private void sort() {
		
		String a, b;
		String temp;
		
		for (int i = 0; i < GIDList.size(); i++) {
		for (int j = 0; j < GIDList.size(); j++) {
			a = GIDList.get(i);
			b = GIDList.get(j+1);
			temp = GIDList.get(j);
			
			if (a.compareTo(b) > 0 ) {
				GIDList.set(i, GIDList.get(j+1));
				GIDList.set(j+1, temp);
			}
			
		}
			
		}
	}
	
	
	public Main() {
		int input;
		do {
			System.out.println("Sunib Festival");
			System.out.println("===============");
			System.out.println("1. Register for the exhibition");
			System.out.println("2. View all exhibits");
			System.out.println("3. Update exhibits");
			System.out.println("4. Delete exhibits");
			System.out.println("5. Exit");
			input = scan.nextInt();
			scan.nextLine();
			switch (input) {
			case 1:
				registerEx();
				break;
				
			case 2:
				if(GIDList.isEmpty()) {
					System.out.println("There is no exhibition yet!");
				}else {
				viewEx();	
				}
				break;
			
			case 3:
				if(GIDList.isEmpty()) {
					System.out.println("There is no exhibition yet!");
				}else {
				
				updateEx();
				}
				break;
				
			case 4:
				if(GIDList.isEmpty()) {
					System.out.println("There is no exhibition yet!");
				}else {
			
				deleteEx();
				}
				break;
				
			default:
				break;
			}

		} while (input != 5);
	}

	private void registerEx() {
	String GName ="", idea = "", location ="", feedbackLink ="";
	
	do {
		System.out.println("Input Group Name [ Must be alphabetic and Unique ] : ");
		GName = scan.nextLine();
	} while (!(check(GName) == true && GNameList.contains(GName) == false ));
	
	do {
		System.out.println("Input idea [ Must atleast contain 3 words ] : ");
		idea = scan.nextLine();
	} while(!(idea.split(" ").length >= 3));
	
	do {
		System.out.println("Input Location [ Must end with 'lt.1' , 'lt.2' , or 'lt.3' ]: ");
		location = scan.nextLine();
	} while (!(location.contains("lt.1") || location.contains("lt.2")  || location.contains("lt.3")));
	
	do {
		System.out.println("Input feedback link [ Must start with 'forms.com/");
		feedbackLink = scan.nextLine();
	} while (!(feedbackLink.startsWith("forms.com/")));
	
	String randomid ="";
	randomid = "TB" + rand.nextInt(1000);
	
	System.out.println("Exhibition Information");
	System.out.println("=======================");
	System.out.println("Table ID: " +randomid);
	System.out.println("Group Name: " +GName);
	System.out.println("Idea: " +idea);
	System.out.println("Location: " +location);
	System.out.println("Feedback Link: " +feedbackLink);

	GIDList.add(randomid);
	GNameList.add(GName);
	ideaList.add(idea);
	locationList.add(location);
	feedbackList.add(feedbackLink);	
	}
	
	private void viewEx() {
	sort();
	for (int i = 0; i < GIDList.size(); i++) {
		System.out.println("Table ID: " +GIDList.get(i));
		System.out.println("Group Name: " +GNameList.get(i));
		System.out.println("Idea: " +ideaList.get(i));
		System.out.println("Location: " +locationList.get(i));
		System.out.println("Feedback Link: " +feedbackList.get(i));

	}
	}
	
	private void updateEx() {
		sort();
		String updating ="";
		viewEx();
		do {
			System.out.println("Input Table ID [ e.g TB432 ] : ");
			updating = scan.nextLine();
		} while (!(GIDList.contains(updating)));
		
		int i = GIDList.indexOf(updating);
		
		String newloc = "";
		do {
			System.out.println("Input Location [ Must end with 'lt.1', 'lt.2', or 'lt.3'] : ");
			newloc = scan.nextLine();
		}while (!(newloc.contains("lt.1") || newloc.contains("lt.2") || newloc.contains("lt.3")));
		locationList.set(i, newloc);
	}
	
	private void deleteEx() {
		
		String deleting ="";
		do {
			System.out.println("Input Table ID [ e.g TB432 ] : ");
			deleting = scan.nextLine();
		}while (!(GIDList.contains(deleting)));
		
		int i= GIDList.indexOf(deleting);
		
		GIDList.remove(i);
		GNameList.remove(i);
		ideaList.remove(i);
		locationList.remove(i);
		feedbackList.remove(i);
	}
	public static void main(String[] args) {
		new Main();

	}

}
